print(Insert a number)

