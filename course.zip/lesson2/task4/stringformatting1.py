player_name = "firstname lastname"

player_name.REPLACE
player_name.REPLACE