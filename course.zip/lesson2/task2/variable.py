REPLACE = raw_input("What's your name? >")
