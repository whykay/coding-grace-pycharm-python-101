print(REPLACE("What's your name? > "))

