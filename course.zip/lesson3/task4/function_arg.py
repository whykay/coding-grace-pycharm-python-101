REPLACE
    # You expect a reason why the player died. It's a string.
    print("{}. Good job!".format(REPLACE))

    # This exits the program entirely.
    exit(0)

if __name__ == '__main__':
REPLACE(REPLACE)
