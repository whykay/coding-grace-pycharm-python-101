treasure_chest = ["diamonds", "gold", "silver", "sword"]

# Get the first item in the list
print(treasure_chest[REPLACE])

# Get the second item in the list
print(treasure_chest[REPLACE])

# Get the last item in the list
print(treasure_chest[REPLACE])

# Get the first two items on the list
print(treasure_chest[REPLACE])