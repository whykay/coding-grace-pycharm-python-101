treasure_chest = ["diamonds", "gold", "silver", "sword"]

print("The number of items in the treasure is: {}".format(TODO(TODO)))
