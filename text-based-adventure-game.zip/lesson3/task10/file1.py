treasure_chest = ["diamonds", "gold", "silver", "sword"]
print(TODO.TODO(TODO))

