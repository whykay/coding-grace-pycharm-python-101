# Some notes:
# a) The '#' symbols mean comments and Python will ignore these lines of code
# b) When indenting code, it's always "4 spaces". Some editors allow you to use tabs
#    and it converts it to 4 spaces automatically for you.

def main():
    player_name =  raw_input("What's your name? >")
    print("Your name is {}".format(player_name.upper()))

if __name__ == '__main__':
    # This calls a function called "main"
    REPLACE
