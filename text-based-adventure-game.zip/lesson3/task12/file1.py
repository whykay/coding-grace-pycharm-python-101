# The guard is sleeping, so he's not moving.
guard_moved = TODO

if guard_moved:
    print("The guard has moved!")
else:
    print("He's snoring away. He's not moving anywhere anytime soon.")