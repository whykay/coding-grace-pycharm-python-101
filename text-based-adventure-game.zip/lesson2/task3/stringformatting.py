player_name = raw_input("What's your name? >")

print("REPLACE".format(REPLACE))

## Try other string built-in functions.
## Find it in Python docs by
## 1) https://www.python.org/
## 2) Click on Docs
## 3) Click on "Library Reference"
## 4) Look for "Text Sequence Type - str" and read up the various functions (or methods)
##    and experiment in your Python interpretor.