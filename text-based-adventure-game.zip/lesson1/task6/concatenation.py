print(string1 + string2)
